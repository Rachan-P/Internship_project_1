function menu(){
   const menu=document.querySelector(".menu_links");
   const icon=document.querySelector(".icon");
   menu.classList.toggle("open");
   icon.classList.toggle("open");
}
var typed = new Typed(".p2", {
    strings: ["Student", "Developer", "Technophile", "Designer"],
    typeSpeed: 100,
    backSpeed: 60,
    loop: true
});
var typed = new Typed(".p4", {
    strings: ["Student", "Developer", "Technophile", "Designer"],
    typeSpeed: 100,
    backSpeed: 60,
    loop: true
});